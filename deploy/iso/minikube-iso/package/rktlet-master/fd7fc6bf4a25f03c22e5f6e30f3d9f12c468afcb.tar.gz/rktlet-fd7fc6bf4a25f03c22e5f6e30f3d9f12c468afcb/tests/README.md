# Tests

This directory contains integration tests of the rktlet.

They use the locally installed `rkt` and `systemd-run` binaries, which must be present in your path.

They also require root privileges.
